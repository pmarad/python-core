"""
Simple Pandas program to combine Excel files and summarize data.
This demonstrates the use of Gooey to add a simple UI on top of the script
"""
from __future__ import print_function
import pandas as pd
import numpy as np
import glob
import os
import json
from argparse import ArgumentParser
from gooey import Gooey, GooeyParser
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D 


@Gooey(program_name="Create Yealy GITAM Placement Report")
def parse_args():
    """ Use GooeyParser to build up the arguments we will use in our script
    Save the arguments in a default json file so that we can retrieve them
    every time we run the script.
    """
    stored_args = {}
    # get the script name without the extension & use it to build up
    # the json filename
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    print(script_name)
    args_file = "{}-args.json".format(script_name)
    print(args_file)
    # Read in the prior arguments as a dictionary
    if os.path.isfile(args_file):
        with open(args_file) as data_file:
            stored_args = json.load(data_file)
    parser = GooeyParser(description='Create Yealy GITAM Placement Report')
    parser.add_argument('data_directory',
                        action='store',
                        default=stored_args.get('data_directory'),
                        widget='DirChooser',
                        help="Source directory that contains Excel files")
    parser.add_argument('output_directory',
                        action='store',
                        widget='DirChooser',
                        default=stored_args.get('output_directory'),
                        help="Output directory to save Placement report")
    parser.add_argument('placement_file',
                        action='store',
                        default=stored_args.get('placement_file'),
                        widget='FileChooser',
                        help='GITAM Yearly Placement Files')
    parser.add_argument('-d', help='Start date to include',
                        default=stored_args.get('d'),
                        widget='DateChooser')
    args = parser.parse_args()
    # Store the values of the arguments so we have them next time we run
    with open(args_file, 'w') as data_file:
        # Using vars(args) returns the data as a dictionary
        json.dump(vars(args), data_file)
    return args


def combine_files(src_directory):
    """ Read in all of the gitam placement xlsx files yearly reports and combine into 1
    combined DataFrame
    """
    all_data = pd.DataFrame()
    for f in glob.glob(os.path.join(src_directory, "gitam_*.xlsx")):
        df = pd.read_excel(f)
        all_data = all_data.append(df, ignore_index=True)
    #all_data['date'] = pd.to_datetime(all_data['date'])
    return all_data


def add_gitam_placement_status(placement_data, placement_file):
    """ Read in the gitam placement file and combine with the students data
    Return the gitam placement with their status as an ordered category
    """
    df = pd.read_excel(placement_file)
    all_data = pd.merge(placement_data, df, how='left')
    # Default
    #all_data['Companies'].fillna('', inplace=True)
    # Convert the status to a category and order it
    # all_data["Branch"] = all_data["Branch"].astype("category")
    # all_data["Branch"].cat.set_categories(["CSE", "ECE", "IT", "EEE","MECH","CIVIL"], inplace=True)
    return all_data


def save_results(placement_data, output):
    """ Perform a summary of the data and save the data as an excel file
    """
    print(placement_data)
    summarized_placement_results = placement_data.groupby(["Branch","Year"])["Students Selected"].sum()
    print(summarized_placement_results)
    output_file = os.path.join(output, "placement-report.xlsx")
    print(output_file)
    #summarized_placement_results = summarized_placement_results.reset_index()
    with pd.ExcelWriter(output_file) as writer:
        summarized_placement_results.to_excel(writer,sheet_name='Sheet1',engine='xlsxwriter')
    return summarized_placement_results
    # writer = pd.ExcelWriter(output_file, engine='xlsxwriter')
    # summarized_placement_results = summarized_placement_results.reset_index()
    # print(summarized_placement_results)
    # summarized_placement_results.to_excel(writer)


if __name__ == '__main__':
    conf = parse_args()
    print("Reading GITAM Yearly Placement files")
    placements_df = combine_files(conf.data_directory)
    print(placements_df)
    print("Reading placement data and combining with yearly reports")
    gitam_placement_status = add_gitam_placement_status(placements_df, conf.placement_file)
    print(gitam_placement_status)
    print("Saving gitam placements and students selected summary data")
    final_results = save_results(gitam_placement_status, conf.output_directory)
    #fig, ax = plt.subplots(figsize=(95,70))
    #final_results.unstack().plot(ax=ax)
    final_results.plot(x="Branch", y=["Year", "Companies", "Students Selected"], kind="bar")
    #final_results.plot(x="Companies", y=["Year", "Branch", "Students Selected"], kind="box")
    plt.show()



	
	
	